# ✈️ Airline Revenue System

A simple Flask web application that calculates airline revenue based on passenger counts, distance flown, and aircraft type.  
It applies surcharges, discounts, and bonuses dynamically to show a detailed revenue breakdown.

---

## 🚀 Features

- 🧮 Calculates base revenue using per-km class rates for Economy, Business, and First Class.
- ✈️ Supports 3 aircraft types: **A320**, **B737**, and **A380**.
- 💰 Applies:
  - +10% **Surcharge** if total passengers > 300  
  - -5% **Discount** if distance > 5000 km  
  - +₹100,000 **Bonus** if aircraft is A380 and passengers > 250
- 📊 Displays a clean **revenue breakdown** using Bootstrap styling.
- 🧑‍💻 Built with Flask (Python), HTML, CSS (Bootstrap), and Jinja2.

---

## 🧠 Pricing Table

| Aircraft | Economy | Business | First Class |
|-----------|----------|-----------|--------------|
| **A320** | ₹5 | ₹10 | ₹20 |
| **B737** | ₹6 | ₹12 | ₹25 |
| **A380** | ₹8 | ₹15 | ₹30 |

---

## 🏗️ How to Run

Paste and run this command in your terminal:
ARS\Scripts\activate

Step 2: Navigate to your project directory
Go to this location in your terminal:
RP2\ARS-Project\ARS\airline_revenue_app>

Step 3: Run the Flask application
Type one of the following commands:
py app.py
or
python app.py

After running, open your browser and go to:
http://127.0.0.1:5000/

Your Airline Revenue System will now be running locally.


## Screenshots


![index page ](screenshots/result.png)
![page with values](screenshots/calculation.png)
![calculated result](screenshots/calculation.png)