from flask import Flask, render_template,request

app = Flask(__name__)

@app.route('/')
def home():
        return render_template('index.html')


@app.route('/calculate', methods=['POST'])

def calculate():
      if request.method == 'POST':
        print("Form Submitted ✅")
        economy=int(request.form['economy'])
        business=int(request.form['business'])
        first=int(request.form['first'])
        distance=float(request.form['distance'])
        aircraft=(request.form['aircraft'])
        print(f"Aircraft: {aircraft}, Distance: {distance}, Economy: {economy}, Business: {business}, First: {first}")
        rates={
            'B737': {'economy':5,'business':10,'first':20},
            'A320': {'economy':6,'business':12,'first':25},
            'A380': {'economy':8,'business':15,'first':30}
        }

        rate=rates.get(aircraft)
        base_price = ((economy * rate['economy']) +(business * rate['business']) +(first * rate['first'])) * distance

        print(f"Base Price 💵💵: {base_price}")
        total_passengers= economy + business + first
        print(f"Total Passengers 🧑‍🤝‍🧑:{total_passengers}") 

        surcharge=0
        bonus=0
        discount=0

        if total_passengers > 300:
            surcharge= 0.10 * base_price
            base_price += surcharge
            print(f"Surcharge Applied 🚨: {surcharge}")

        if distance > 5000:
            discount= 0.05 * base_price
            base_price -= discount
            print(f"Long Haul Discount Applied ✈️: {discount}")
        
        if aircraft == 'A380' and total_passengers > 250:
            bonus = 100000
            base_price += bonus
            print(f"A380 Bonus Added 🎉: ₹{bonus}")
        total_revenue = base_price
        return render_template(
            'result.html',
            economy=economy,
            business=business,
            first=first,
            distance=distance,
            aircraft=aircraft,
            base_price=base_price,
            surcharge=surcharge,
            discount=discount,
            bonus=bonus,
            total=total_revenue
        )
      else:
           print("Form Not Submitted ❌")
           return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)

